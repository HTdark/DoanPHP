<div class="text-center bg-aquamarine p-4 rounded-lg shadow-lg">
    Thống Kê
</div>
